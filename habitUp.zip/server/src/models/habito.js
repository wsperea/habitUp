import mongoose from 'mongoose';
import { DIAS } from '../constants.js';

const schema = new mongoose.Schema({
  usuario_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true, index: true },
  nombre: { type: String, required: true, trim: true, maxlength: 80 },
  categoria: { type: String, trim: true, default: '', maxlength: 60 },
  descripcion: { type: String, trim: true, default: '', maxlength: 300 },
  frecuencia: {
    dias: { type: [{ type: String, enum: DIAS }], default: [] },
  },
  activo: { type: Boolean, default: true },
  fecha_creacion: { type: Date, default: Date.now },
}, { collection: 'habitos', versionKey: false });

export const Habito = mongoose.model('Habito', schema);
