import mongoose from 'mongoose';
import { toNoonUtc } from '../util/dates.js';

const schema = new mongoose.Schema({
  habito_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Habito', required: true },
  usuario_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario', required: true },
  fecha: { type: Date, required: true, set: toNoonUtc },
  completado: { type: Boolean, default: true },
}, { collection: 'registros', versionKey: false });

schema.index({ habito_id: 1, fecha: 1 }, { unique: true }); // un registro por hábito y día
schema.index({ usuario_id: 1, fecha: 1 });

export const Registro = mongoose.model('Registro', schema);
