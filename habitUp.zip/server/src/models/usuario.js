import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  nombre: { type: String, required: true, trim: true, maxlength: 60 },
  correo: { type: String, required: true, trim: true, lowercase: true, unique: true, maxlength: 120 },
  password: { type: String, required: true, select: false }, // hash bcrypt; nunca viaja al sitio
  fecha_registro: { type: Date, default: Date.now },
}, { collection: 'usuarios', versionKey: false });

export const Usuario = mongoose.model('Usuario', schema);
