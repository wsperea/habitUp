// Aplicación Express: API en /api y el sitio estático (HTML/CSS/JS) en la raíz.
import express from 'express';
import { config, isProd } from './config.js';
import { healthRouter } from './routes/health.js';

// El sitio vive en la carpeta padre; estas rutas NUNCA deben servirse (código del servidor, .env, etc.).
const PRIVATE_ROOTS = new Set(['server', 'node_modules']);

function blockPrivatePaths(req, res, next) {
  let p;
  try { p = decodeURIComponent(req.path).replace(/\\/g, '/'); } catch { return res.sendStatus(400); }
  const segments = p.split('/').filter(Boolean).map((s) => s.toLowerCase());
  const blocked = segments.some((s) => s.startsWith('.')) || PRIVATE_ROOTS.has(segments[0]);
  return blocked ? res.sendStatus(404) : next();
}

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '100kb' }));

  app.use('/api/health', healthRouter);
  app.use('/api', (req, res) => res.status(404).json({ error: 'Ruta de API no encontrada' }));

  app.use(blockPrivatePaths);
  app.use(express.static(config.siteDir, { dotfiles: 'deny', extensions: ['html'] }));

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error('[habitup] error:', err);
    const body = { error: 'Error interno del servidor' };
    if (!isProd) body.detalle = err.message;
    res.status(500).json(body);
  });

  return app;
}
